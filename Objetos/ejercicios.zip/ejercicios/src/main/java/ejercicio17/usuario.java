package ejercicio17;

import java.time.LocalDate;
import java.util.ArrayList;

import ejercicio14.DateLapse;
import ejercicio14.DateLapseA;
/*
 Conclusiones obtenidas con mati: 
 	Usar Streams!!!! (Repasar Streamssss si o si) 
 	
*/



public class usuario { //Consultarrrrrrrrrrrrrrrrrrr
	String nombre;
	String direccion;
	String DNI;
	ArrayList<reserva> reservas = new ArrayList<reserva>();
	ArrayList<propiedad> propiedades = new ArrayList<propiedad>();
	
	public usuario(String n, String d, String dni) {
		this.nombre = n;
		this.direccion = d;
		this.DNI = dni;
	}
	
	public void crearReserva(propiedad prop, LocalDate inicio, LocalDate fin) {
		reserva res = new reserva(prop, inicio, fin);
		if(!res.prop.equals(null)) {
			this.reservas.add(res);
		}
	}
	
	public boolean cancelarReserva(reserva r) {
		int i = 0;
		boolean retorno = false;
		while(i< this.reservas.size() & !retorno) {
			if(this.reservas.get(i).equals(r)) {
				retorno = this.reservas.get(i).cancelarReserva(this.reservas.get(i).periodo);
			}
		}
		if(retorno) {
			this.reservas.remove(i);
		}
		return retorno;
	}
	
	public void consultarDisponibilidad(propiedad prop, LocalDate inicio, LocalDate fin) {
		prop.consultarDisponibilidad(inicio, fin);
	}
	
	public double calcularIngreso(propiedad prop, LocalDate inicio, LocalDate fin) {
		DateLapseA lapso = new DateLapseA(inicio,fin);
		double precio = prop.calcularPrecio(lapso);
		precio = (precio * 75) / 100;
		return precio;
	}
	
}
