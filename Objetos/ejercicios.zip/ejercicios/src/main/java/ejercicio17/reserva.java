package ejercicio17;

import java.time.LocalDate;

import ejercicio14.*;

public class reserva {
	DateLapse periodo;
	propiedad prop;
	
	public reserva() {
		
	}
	
	public reserva(propiedad propiedad, LocalDate inicio, LocalDate fin) {  //crear reserva?
		if(propiedad.consultarDisponibilidad(inicio, fin)) {
			this.periodo = new DateLapseA(inicio,fin);
			propiedad.ocuparPropiedad(inicio, fin);
			this.prop = propiedad;
		} else {
			System.out.println("La propiedad no esta disponible, no se ha creado la reserva");
			this.prop = null;
		}
	}
	
	public double calcularPrecio() {
		double precio = this.periodo.sizeInDays() * this.prop.precioXnoche;
		return precio;
	}
	
	public boolean cancelarReserva(DateLapse lapso) {
		boolean resultado = this.prop.cancelarOcupacion(lapso);
		return resultado;
	}
	
}