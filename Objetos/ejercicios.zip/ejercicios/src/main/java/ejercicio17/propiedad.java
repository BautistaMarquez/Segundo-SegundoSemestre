package ejercicio17;

import java.time.LocalDate;
import java.util.ArrayList;

import ejercicio14.DateLapse;
import ejercicio14.DateLapseA;

public class propiedad {
	String direccion;
	String nombreDescriptivo;
	double precioXnoche;
	ArrayList<DateLapse> ocupacion = new ArrayList<DateLapse>();
	
	public propiedad(String d, String n, Double p) { 
		this.direccion = d;
		this.nombreDescriptivo = n;
		this.precioXnoche = p;
	}
	
	public boolean consultarDisponibilidad(LocalDate inicio, LocalDate fin) {
		DateLapseA lapso = new DateLapseA(inicio,fin);
		boolean disponible = true;
		int i = 0;
		while (i<this.ocupacion.size() & !ocupacion.get(i).overlaps(lapso)) {
			i = i+1;
		}
		if(i<this.ocupacion.size()) {
			disponible = false;
		}
		return disponible;
	}
	
	public void ocuparPropiedad(LocalDate inicio, LocalDate fin) {
		boolean disponible = this.consultarDisponibilidad(inicio, fin);
		if(disponible) {
			DateLapseA lapso = new DateLapseA(inicio,fin);
			this.ocupacion.add(lapso);
		}
	}
	
	public boolean cancelarOcupacion(DateLapse lapso) {
		int i;
		boolean retorno = false;
		for(i=0; i<this.ocupacion.size(); i++) {
			if( LocalDate.now().isBefore(lapso.getFrom()) & this.ocupacion.get(i).equals(lapso)) {
				this.ocupacion.remove(i);
				retorno = true;
			}
			i = i+1;
		}
		return retorno;
	}
	
	public double calcularPrecio(DateLapse lapso) {
		int i;
		double precio = 0;
		for(i=0; i<this.ocupacion.size(); i++) {
			if(this.ocupacion.get(i).overlaps(lapso)) {
				if(lapso.getFrom().isBefore(this.ocupacion.get(i).getFrom())) {
					DateLapse lapso2 = new DateLapseA(this.ocupacion.get(i).getFrom(),lapso.getTo());
					precio = precio + (this.precioXnoche * lapso2.sizeInDays());
				} else if(lapso.getFrom().isAfter(this.ocupacion.get(i).getFrom()) && (lapso.getTo().isAfter(this.ocupacion.get(i).getTo()))){
					DateLapse lapso3 = new DateLapseA(lapso.getFrom(),this.ocupacion.get(i).getTo());
					precio = precio + (this.precioXnoche * lapso3.sizeInDays());
				} else {
					precio = precio + (this.precioXnoche * lapso.sizeInDays());
				}
			}
		}
		return precio;
	}
	
	
}