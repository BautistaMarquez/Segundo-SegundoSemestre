package ejercicio14;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DateLapseA implements DateLapse {
	
	private LocalDate from;
	private LocalDate to;
	
	public DateLapseA() {
		
	}
	public DateLapseA(LocalDate f, LocalDate t) {
		if(f.isBefore(t)) {
			this.from = f;
			this.to = t;
		}else {
			this.from = t;
			this.to = f;
		}
		
		
	}
	
	public LocalDate getFrom() {
		return this.from;
	}

	public LocalDate getTo() {
		return this.to;
	}

	public int sizeInDays() {
		int dias = (int) from.until(to, ChronoUnit.DAYS);
		return dias;
	}

	public boolean includesDate(LocalDate other) {
		if((other.isAfter(this.from) || other.isEqual(this.from)) && (other.isBefore(this.to) || other.isEqual(this.to))) {
			return true;
		} else return false;
	}
	
	public boolean overlaps (DateLapse lapso) {
		if(lapso.includesDate(this.from) || lapso.includesDate(this.to)) {
			return true;
		} else return false;
	}
}
