package ejercicio15;

public class Persona {
	String nombre;
	domicilio domicilio;
	
	
	public Persona(String n, domicilio d) {
		this.nombre = n;
		this.domicilio = d;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public domicilio getDomicilio() {
		return this.domicilio;
	}
	
	public void cambiarDomicilio(domicilio d) {
		this.domicilio = d;
	}
}
