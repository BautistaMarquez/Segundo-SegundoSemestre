package ejercicio15;

import java.util.ArrayList;
import java.util.List;

public class domicilio {
	
	String direccion;
	private List<Double> ConsumoDeEnergiaActiva = new ArrayList<Double>();
	private List<Double> ConsumoDeEnergiaReactiva = new ArrayList<Double>();
	
	public domicilio(String d) {
		this.direccion = d;
	}
	
	public void cargarConsumoActivo(double consumo) {
		this.ConsumoDeEnergiaActiva.add(consumo);
	}
	
	public void cargarConsumoReactivo(double consumo) {
		this.ConsumoDeEnergiaReactiva.add(consumo);
	}
	
	public double obtenerConsumoActivo() {
		 double consumo = this.ConsumoDeEnergiaActiva.get(this.ConsumoDeEnergiaActiva.size()-1);
		 return consumo;
	}
	
	public double obtenerConsumoReactivo() {
		 double consumo = this.ConsumoDeEnergiaReactiva.get(this.ConsumoDeEnergiaReactiva.size()-1);
		 return consumo;
	}
	
	public String obtenerDireccion() {
		return this.direccion;
	}
	
}
