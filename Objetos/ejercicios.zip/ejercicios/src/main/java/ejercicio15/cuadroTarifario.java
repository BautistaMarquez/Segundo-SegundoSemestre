package ejercicio15;

public class cuadroTarifario {
	double preciokWh;
	
	public cuadroTarifario(){
		
	}
	
	public void setearPrecio(double p) {
		this.preciokWh = p;
	}
	
	public double obtenerPrecio() {
		return this.preciokWh;
	}
}
