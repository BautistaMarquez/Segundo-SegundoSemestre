package ejercicio15;

import java.time.LocalDate;

public class factura { //La forma en que calculo el monto y realizo la bonificacion podria ser otra, no se si deberia seguir algun orden estipulo intente no hacer todo en el metodo calcularMontoFinal.
	String nombrePersona;
	LocalDate fechaActual;
	boolean bonificacion = false;
	double montoFinal;
	
	public factura(Persona cliente, double valorkWh) {
		this.fechaActual = LocalDate.now();
		this.nombrePersona = cliente.getNombre();
		this.calcularMontoFinal(cliente.getDomicilio(), valorkWh);
		if(this.bonificacion) {
			this.realizarBonificacion();
		}
	}
	
	public void calcularMontoFinal(domicilio d,double valorkWh) {
		this.montoFinal = d.obtenerConsumoActivo() * valorkWh;
		double factorPotencia = d.obtenerConsumoActivo() / Math.sqrt(Math.pow(d.obtenerConsumoActivo(), 2) + Math.pow(d.obtenerConsumoReactivo(), 2));
		if(factorPotencia > 0.8) {
			this.bonificacion = true;
		}
	}
	
	public void realizarBonificacion() {
		this.montoFinal = this.montoFinal - (this.montoFinal * 0.1);
	}
	
	public String obtenerPersona() {
		return this.nombrePersona;
	}
	
	public LocalDate obtenerFechaDeFactura() {
		return this.fechaActual;
	}
	
	public boolean verificarBonificacion() {
		return this.bonificacion;
	}
	
	public double obtenerMontoFinal() {
		return this.montoFinal;
	}
	
	public factura emitirFactura() {
		return this;
	}
	
}
