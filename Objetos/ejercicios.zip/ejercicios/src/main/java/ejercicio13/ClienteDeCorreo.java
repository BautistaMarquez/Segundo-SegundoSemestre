package ejercicio13;

import java.util.ArrayList;
import java.util.List;
//Para el tema de que la busqueda sea mas facil, el INBOX podria ser la Carpetas[0]?Consultar.
public class ClienteDeCorreo {
	private Carpeta inbox;
	private List<Carpeta> carpetas;
	
	public ClienteDeCorreo() {
		 this.inbox = new Carpeta("inbox");
		 this.carpetas = new ArrayList<Carpeta>();
		 this.carpetas.add(this.inbox);
	}
	
	
	
	public void agregarCarpeta(Carpeta carp) {
		this.carpetas.add(carp);
	}

	public void recibir(Email email) {
		this.inbox.agregarEmail(email);
	}
	
	public Email buscar(String texto) {
		Email resultado = this.carpetas.stream().map(c -> c.buscarEmail(texto)).findFirst().orElse(null);
		
		return resultado;
	}
	
	public int espacioOcupado() {
		int espacio = this.inbox.retornarTamaño() + this.carpetas.stream().mapToInt(c -> c.retornarTamaño()).sum();
		return espacio;
	}
}
