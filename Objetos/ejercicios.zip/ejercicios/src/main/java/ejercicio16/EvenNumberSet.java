package ejercicio16;


import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class EvenNumberSet<E> extends LinkedHashSet<Integer> { //podria no hacer el Override, capaz? esto funciona, no estoy seguro si es lo que habria que hacer

	@Override
	public boolean add(Integer i) {
		if(i == null) {
			return false;
		}
		if(i % 2 == 0) {
			super.add(i);
			return true;
		} else return false;
	}

}
