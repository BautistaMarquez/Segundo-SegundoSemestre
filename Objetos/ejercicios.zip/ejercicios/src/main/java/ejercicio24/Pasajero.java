package ejercicio24;

public class Pasajero extends Usuario{
	
	private Viaje ultimoViaje;
	
	public Pasajero(String n, double s) {
		super(n,s);
	}
	
	public void cargarSaldo(Usuario u, double saldo) {
		this.saldo = this.saldo + saldo;
		//if((LocalDate.now() - this.ultimoViaje.getFecha()) < 30) {
			this.saldo = this.saldo - (this.saldo * 0.1);
		//}
	}
	
	public void agregarViaje(Viaje v) {
		this.ultimoViaje = v;
	}
	
	public void pagarViaje(double precio) {
		if(this.ultimoViaje != null) {
			precio = precio - 500;
		}
		this.saldo = this.saldo - precio;
	}

	public Viaje getUltimoViaje() {
		return ultimoViaje;
	}
	
}
