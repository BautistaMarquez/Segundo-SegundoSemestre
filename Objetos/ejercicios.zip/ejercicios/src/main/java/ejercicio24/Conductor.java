package ejercicio24;

public class Conductor extends Usuario {
	private Vehiculo vehiculo;
	
	public Conductor(String n, double s) {
		super(n,s);
	}
	
	public void cargarSaldo(Usuario u, double saldo) {
		this.saldo = this.saldo + saldo;
		if(this.vehiculo.getAnio() > 2018) {
			this.saldo = this.saldo - (this.saldo * 0.01);
		} else {
			this.saldo = this.saldo - (this.saldo * 0.1);
		}
	}
	
	public void setVehiculo(Vehiculo v) {
		this.vehiculo = v;
	}
	
	public void pagarViaje(double precio) {
		precio = precio - (this.vehiculo.getValor() * 0.01);
		this.saldo = this.saldo - precio;
	}
}
