package ejercicio24;

public class Vehiculo {
	
	private Conductor conductor;
	private int capacidad;
	private String descripcion;
	private int anio;
	private double valor;
	
	public Vehiculo(Conductor cond, int c, String d, int a, double v) {
		this.conductor = cond;
		this.capacidad = c;
		this.descripcion = d;
		this.anio = a;
		this.valor = v;
	}
	
	
	public int getCapacidad() {
		return this.capacidad;
	}
	
	public Conductor getConductor() {
		return this.conductor;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public int getAnio() {
		return anio;
	}

	public double getValor() {
		return valor;
	}
	
	
}
