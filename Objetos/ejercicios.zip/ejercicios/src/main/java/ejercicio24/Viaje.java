package ejercicio24;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Viaje {
	
	private String origen;
	private String destino;
	private double costoTotal;
	private Vehiculo vehiculo;
	private List<Usuario> Pasajeros = new ArrayList<Usuario>();
	private LocalDate fecha;
	
	public void darAlta(String o, String d, double costo, Vehiculo v, LocalDate f) {
		this.origen = o;
		this.destino = d;
		this.costoTotal = costo;
		this.vehiculo = v;
		this.Pasajeros.add(v.getConductor());
		this.fecha = f;
	}
	
	public void registrarPasajero(Pasajero p, Viaje v) {
		//if((this.Pasajeros.size() < this.vehiculo.getCapacidad()) & (p.saldo > 0)) {
			//int fecha LocalDate.now() - this.fecha; //VER COMO SE HACE ESTO
			//if(fecha > 2){
				this.Pasajeros.add(p);
			//}
		//}
	}
	
	public LocalDate getFecha() {
		return this.fecha;
	}
	
	public void procesar() {
		double valor = this.costoTotal / this.Pasajeros.size();
		this.Pasajeros.forEach( p -> p.pagarViaje(valor));
	}

	public String getOrigen() {
		return origen;
	}

	public String getDestino() {
		return destino;
	}

	public double getCostoTotal() {
		return costoTotal;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public List<Usuario> getPasajeros() {
		return Pasajeros;
	}
	
	
	
}