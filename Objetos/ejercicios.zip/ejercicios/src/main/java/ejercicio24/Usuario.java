package ejercicio24;

public abstract class Usuario {
	protected String nombre;
	protected double saldo;
	
	public Usuario(String n, double s) {
		this.nombre = n;
		this.saldo = s;
	}
	
	
	
	public String getNombre() {
		return nombre;
	}



	public double getSaldo() {
		return saldo;
	}



	public abstract void cargarSaldo(Usuario u, double s);
	
	public abstract void pagarViaje(double p);
}
