package ar.edu.unlp.info.oo1.ejercicio5;

public interface Figura { //o hacerlo interface
	
	public abstract double getPerimetro();
	
	public abstract double getArea();
	
	public abstract void setPerimetro();
	
	public abstract void setArea();
}
