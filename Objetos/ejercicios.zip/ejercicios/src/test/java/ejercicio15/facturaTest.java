package ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ejercicio15.*;

public class facturaTest {
	cuadroTarifario tarifa = new cuadroTarifario();
	domicilio domicilio = new domicilio("1y50");
	Persona cliente = new Persona("JuanCarlos",domicilio);
	factura facturaAPagar;

	@BeforeEach
	public void set() {
		tarifa.setearPrecio(10);
		domicilio.cargarConsumoActivo(5);
		domicilio.cargarConsumoActivo(15);
		domicilio.cargarConsumoActivo(10);
		domicilio.cargarConsumoReactivo(4);
		domicilio.cargarConsumoReactivo(12);
		domicilio.cargarConsumoReactivo(0);
		
		facturaAPagar = new factura(cliente,tarifa.obtenerPrecio());
	}
	
	@Test
	public void calculosTest() {
		assertEquals("JuanCarlos",facturaAPagar.obtenerPersona());
		assertEquals(true,facturaAPagar.verificarBonificacion());
		assertEquals(90,facturaAPagar.obtenerMontoFinal());
	}
}
