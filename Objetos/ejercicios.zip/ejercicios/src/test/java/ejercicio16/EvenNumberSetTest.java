package ejercicio16;

import ejercicio16.*;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ejercicio14.DateLapseA;
import ejercicio14.DateLapseB;

public class EvenNumberSetTest {
	EvenNumberSet<Integer> testeo;
	
	@BeforeEach
	public void set() {
		testeo = new EvenNumberSet<Integer>();
		testeo.add(2);
		testeo.add(1);
		testeo.add(3);
		testeo.add(null);
		testeo.add(2);
		testeo.add(1);
		testeo.add(3);
		testeo.add(4);
		testeo.add(7);
		testeo.add(8);
		testeo.add(null);
	}
	
	@Test
	public void testAdd() {
		assertEquals(3,testeo.size());
		assertEquals(true,testeo.add(2));
		assertEquals(true,testeo.add(10));
		assertEquals(false,testeo.add(3));
		assertEquals(false,testeo.add(7));
	}
}
