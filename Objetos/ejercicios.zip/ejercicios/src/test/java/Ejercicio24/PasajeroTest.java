package Ejercicio24;

public class PasajeroTest {

}
