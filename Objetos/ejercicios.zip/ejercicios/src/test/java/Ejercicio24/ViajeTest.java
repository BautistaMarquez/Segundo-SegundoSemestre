package Ejercicio24;

import Ejercicio24.*;
import ejercicio24.Conductor;
import ejercicio24.Pasajero;
import ejercicio24.Vehiculo;
import ejercicio24.Viaje;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ViajeTest {

	Viaje viajeTest;
	Conductor conductorTest;
	Vehiculo vehiculoTest;
	Pasajero pasajeroTest1;
	Pasajero pasajeroTest2;
	Pasajero pasajeroTest3;
	Pasajero pasajeroTest4;
	
	@BeforeEach
	public void set() {
		viajeTest = new Viaje();
		conductorTest = new Conductor("Juan",1000);
		vehiculoTest = new Vehiculo(conductorTest,5,"AutoBMW",2020,20000);
		conductorTest.setVehiculo(vehiculoTest);
		pasajeroTest1 = new Pasajero("Juan",2000);
		pasajeroTest2 = new Pasajero("Juan",3000);
		pasajeroTest3 = new Pasajero("Juan",1100);
		pasajeroTest4 = new Pasajero("Juan",400);
		viajeTest.darAlta("VillaElisa", "LaPlata", 10000, vehiculoTest, LocalDate.now());
	}
	
	
	@Test
	public void testRegistrar() {
		viajeTest.registrarPasajero(pasajeroTest1, viajeTest);
		viajeTest.registrarPasajero(pasajeroTest2, viajeTest);
		viajeTest.registrarPasajero(pasajeroTest3, viajeTest);
		viajeTest.registrarPasajero(pasajeroTest4, viajeTest);
		assertEquals(5,viajeTest.getPasajeros().size());
		viajeTest.procesar();
		assertEquals(0,pasajeroTest1.getSaldo());
		assertEquals(1000,pasajeroTest2.getSaldo());
		
	}
	
}
